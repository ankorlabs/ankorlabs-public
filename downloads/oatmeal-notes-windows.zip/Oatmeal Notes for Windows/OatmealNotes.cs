// Oatmeal Notes for Windows — disposable notes.
// - Every open makes a new note.
// - Open notes autosave, so they survive a restart, crash or sign-out.
// - Closing a note (its X button or Ctrl+W) deletes it for good.
// - Every 5 minutes notes fade in on top of other windows (pause button in each note's corner).
// Written in C# 5 so Windows' built-in .NET Framework compiler can also build it.

using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace OatmealNotes
{
    static class Program
    {
        const string MutexName = "OatmealNotes_SingleInstance_v1";
        const string EventName = "OatmealNotes_NewNote_v1";

        [DllImport("user32.dll")] static extern bool SetProcessDPIAware();

        [STAThread]
        static void Main()
        {
            bool createdNew;
            using (var mutex = new Mutex(true, MutexName, out createdNew))
            {
                if (!createdNew)
                {
                    // Already running: ask that copy to make another note, then leave.
                    try
                    {
                        using (var ev = EventWaitHandle.OpenExisting(EventName)) ev.Set();
                    }
                    catch (Exception) { }
                    return;
                }

                try { SetProcessDPIAware(); } catch (Exception) { }
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                var ev2 = new EventWaitHandle(false, EventResetMode.AutoReset, EventName);
                var ctx = new NotesContext(ev2);
                Application.Run(ctx);
                GC.KeepAlive(mutex);
            }
        }
    }

    class NotesContext : ApplicationContext
    {
        public static readonly Color Oatmeal = Color.FromArgb(242, 235, 219);
        public static readonly Color Ink = Color.FromArgb(38, 38, 38);

        readonly List<NoteForm> notes = new List<NoteForm>();
        readonly string saveFile;
        readonly System.Windows.Forms.Timer saveTimer;
        readonly Control invoker;
        bool shuttingDown;

        // Rising to the front every 5 minutes
        const int RiseIntervalMs = 5 * 60 * 1000;
        readonly System.Windows.Forms.Timer riseTimer;
        readonly System.Windows.Forms.Timer fadeTimer;
        readonly List<NoteForm> fading = new List<NoteForm>();
        readonly string pauseFile;
        bool risingPaused;
        public bool RisingPaused { get { return risingPaused; } }

        [DllImport("user32.dll")]
        static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int x, int y, int cx, int cy, uint flags);
        static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);
        static readonly IntPtr HWND_NOTOPMOST = new IntPtr(-2);
        const uint SWP_NOSIZE = 0x0001, SWP_NOMOVE = 0x0002, SWP_NOACTIVATE = 0x0010, SWP_SHOWWINDOW = 0x0040;

        public NotesContext(EventWaitHandle newNoteSignal)
        {
            string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "OatmealNotes");
            Directory.CreateDirectory(dir);
            saveFile = Path.Combine(dir, "notes.txt");

            invoker = new Control();
            invoker.CreateControl();
            var h = invoker.Handle; // force handle creation on the UI thread

            saveTimer = new System.Windows.Forms.Timer();
            saveTimer.Interval = 300;
            saveTimer.Tick += delegate { saveTimer.Stop(); SaveNow(); };

            pauseFile = Path.Combine(dir, "rising-paused");
            risingPaused = File.Exists(pauseFile);
            riseTimer = new System.Windows.Forms.Timer();
            riseTimer.Interval = RiseIntervalMs;
            riseTimer.Tick += delegate { RiseNotes(); };
            riseTimer.Start();
            fadeTimer = new System.Windows.Forms.Timer();
            fadeTimer.Interval = 30;
            fadeTimer.Tick += delegate { FadeStep(); };

            // Listen for "open again" from other launches.
            var listener = new Thread(delegate ()
            {
                while (true)
                {
                    newNoteSignal.WaitOne();
                    try { invoker.BeginInvoke(new MethodInvoker(delegate { NewNote(); })); }
                    catch (Exception) { return; }
                }
            });
            listener.IsBackground = true;
            listener.Start();

            Microsoft.Win32.SystemEvents.SessionEnding += delegate { shuttingDown = true; SaveNow(); };
            Application.ApplicationExit += delegate { if (!shuttingDown) SaveNow(); };

            if (Restore() == 0) NewNote();
        }

        static int Scale(int px)
        {
            using (var g = Graphics.FromHwnd(IntPtr.Zero)) return (int)(px * g.DpiX / 96f);
        }

        public void NewNote()
        {
            var size = new Size(Scale(260), Scale(240));
            Point loc;
            if (notes.Count > 0)
            {
                var last = notes[notes.Count - 1];
                loc = new Point(last.Left + Scale(28), last.Top + Scale(28));
            }
            else
            {
                var wa = Screen.PrimaryScreen.WorkingArea;
                loc = new Point(wa.Left + (wa.Width - size.Width) / 2, wa.Top + (wa.Height - size.Height) / 2);
            }
            var note = MakeNote(Guid.NewGuid().ToString("N"), new Rectangle(loc, size), "");
            note.Show();
            note.Activate();
            note.FocusText();
            SaveSoon();
        }

        // Fade every note in on top of all other windows, without taking keyboard focus.
        void RiseNotes()
        {
            if (risingPaused) return;
            foreach (var n in notes)
            {
                if (!n.Visible) continue;
                n.Opacity = 0.0;
                uint f = SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW;
                SetWindowPos(n.Handle, HWND_TOPMOST, 0, 0, 0, 0, f);   // jump above everything...
                SetWindowPos(n.Handle, HWND_NOTOPMOST, 0, 0, 0, 0, f); // ...then go back to a normal window
                if (!fading.Contains(n)) fading.Add(n);
            }
            if (fading.Count > 0) fadeTimer.Start();
        }

        void FadeStep()
        {
            for (int i = fading.Count - 1; i >= 0; i--)
            {
                var n = fading[i];
                if (n.IsDisposed) { fading.RemoveAt(i); continue; }
                double o = n.Opacity + 0.03;
                if (o >= 1.0) { n.Opacity = 1.0; fading.RemoveAt(i); }
                else n.Opacity = o;
            }
            if (fading.Count == 0) fadeTimer.Stop();
        }

        public void TogglePause()
        {
            risingPaused = !risingPaused;
            try
            {
                if (risingPaused) File.WriteAllText(pauseFile, "paused");
                else File.Delete(pauseFile);
            }
            catch (Exception) { }
            riseTimer.Stop();
            riseTimer.Start(); // full 5 minutes after un-pausing
            foreach (var n in notes) n.ShowPaused(risingPaused);
        }

        NoteForm MakeNote(string id, Rectangle bounds, string text)
        {
            var note = new NoteForm(id, text);
            note.ShowPaused(risingPaused);
            note.PauseClicked += delegate { TogglePause(); };
            note.StartPosition = FormStartPosition.Manual;
            note.Bounds = bounds;
            note.Changed += delegate { SaveSoon(); };
            note.NewNoteRequested += delegate { NewNote(); };
            note.FormClosed += delegate (object s, FormClosedEventArgs e)
            {
                notes.Remove(note);
                if (shuttingDown || e.CloseReason == CloseReason.WindowsShutDown || e.CloseReason == CloseReason.TaskManagerClosing)
                    return; // keep saved copy; Windows is shutting down
                SaveNow();  // user closed it: gone for good
                if (notes.Count == 0) ExitThread();
            };
            notes.Add(note);
            return note;
        }

        int Restore()
        {
            if (!File.Exists(saveFile)) return 0;
            int count = 0;
            foreach (var line in File.ReadAllLines(saveFile))
            {
                var p = line.Split('|');
                if (p.Length != 6) continue;
                try
                {
                    var r = new Rectangle(int.Parse(p[1]), int.Parse(p[2]), int.Parse(p[3]), int.Parse(p[4]));
                    bool visible = false;
                    foreach (var s in Screen.AllScreens) if (s.WorkingArea.IntersectsWith(r)) visible = true;
                    if (!visible)
                    {
                        var wa = Screen.PrimaryScreen.WorkingArea;
                        r.Location = new Point(wa.Left + (wa.Width - r.Width) / 2, wa.Top + (wa.Height - r.Height) / 2);
                    }
                    string text = Encoding.UTF8.GetString(Convert.FromBase64String(p[5]));
                    MakeNote(p[0], r, text).Show();
                    count++;
                }
                catch (Exception) { }
            }
            return count;
        }

        void SaveSoon() { saveTimer.Stop(); saveTimer.Start(); }

        void SaveNow()
        {
            var sb = new StringBuilder();
            foreach (var n in notes)
            {
                var b = n.WindowState == FormWindowState.Normal ? n.Bounds : n.RestoreBounds;
                sb.Append(n.NoteId).Append('|')
                  .Append(b.X).Append('|').Append(b.Y).Append('|')
                  .Append(b.Width).Append('|').Append(b.Height).Append('|')
                  .Append(Convert.ToBase64String(Encoding.UTF8.GetBytes(n.NoteText)))
                  .Append("\r\n");
            }
            try
            {
                string tmp = saveFile + ".tmp";
                File.WriteAllText(tmp, sb.ToString());
                if (File.Exists(saveFile)) File.Replace(tmp, saveFile, null);
                else File.Move(tmp, saveFile);
            }
            catch (Exception) { }
        }
    }

    class NoteForm : Form
    {
        public readonly string NoteId;
        public event EventHandler Changed;
        public event EventHandler NewNoteRequested;
        public event EventHandler PauseClicked;
        readonly TextBox box;
        readonly Label pauseButton;
        readonly ToolTip tip = new ToolTip();

        public string NoteText { get { return box.Text; } }

        public NoteForm(string id, string text)
        {
            NoteId = id;
            Text = "Oatmeal Notes";
            FormBorderStyle = FormBorderStyle.SizableToolWindow;
            ShowInTaskbar = true;
            BackColor = NotesContext.Oatmeal;
            MinimumSize = new Size(160, 120);
            Padding = new Padding(10, 8, 30, 6);
            KeyPreview = true;

            box = new TextBox();
            box.Multiline = true;
            box.AcceptsReturn = true;
            box.AcceptsTab = true;
            box.WordWrap = true;
            box.ScrollBars = ScrollBars.None;
            box.BorderStyle = BorderStyle.None;
            box.BackColor = NotesContext.Oatmeal;
            box.ForeColor = NotesContext.Ink;
            box.Font = new Font("Segoe UI", 11f);
            box.Dock = DockStyle.Fill;
            box.Text = text;
            box.TextChanged += delegate { Fire(Changed); };
            Controls.Add(box);

            // Small pause / resume button in the top-right corner.
            pauseButton = new Label();
            pauseButton.AutoSize = false;
            pauseButton.Size = new Size(24, 24);
            pauseButton.TextAlign = ContentAlignment.MiddleCenter;
            pauseButton.Font = new Font("Segoe MDL2 Assets", 10f);
            pauseButton.BackColor = NotesContext.Oatmeal;
            pauseButton.Cursor = Cursors.Hand;
            pauseButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pauseButton.Location = new Point(ClientSize.Width - 28, 4);
            pauseButton.Click += delegate { Fire(PauseClicked); };
            Controls.Add(pauseButton);
            pauseButton.BringToFront();

            LocationChanged += delegate { Fire(Changed); };
            ResizeEnd += delegate { Fire(Changed); };
        }

        public void ShowPaused(bool paused)
        {
            pauseButton.Text = paused ? "\uE768" : "\uE769"; // Play : Pause
            pauseButton.ForeColor = paused ? Color.FromArgb(179, 115, 51) : Color.FromArgb(115, 115, 115);
            tip.SetToolTip(pauseButton, paused
                ? "Paused: notes stay put. Click to have them rise to the front every 5 minutes again."
                : "Notes rise to the front every 5 minutes. Click to pause.");
        }

        void Fire(EventHandler h) { if (h != null) h(this, EventArgs.Empty); }

        public void FocusText()
        {
            box.Focus();
            box.SelectionStart = box.TextLength;
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            box.SelectionStart = box.TextLength;
            box.SelectionLength = 0;
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Control | Keys.N)) { Fire(NewNoteRequested); return true; }
            if (keyData == (Keys.Control | Keys.W)) { Close(); return true; }
            if (keyData == (Keys.Control | Keys.A)) { box.SelectAll(); return true; }
            if (keyData == (Keys.Control | Keys.P)) { Fire(PauseClicked); return true; }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
