@echo off
setlocal
title Oatmeal Notes installer
rem Builds Oatmeal Notes with the C# compiler that ships with Windows,
rem puts it in your user folder, and adds it to the Start menu. No admin needed.

set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
  echo Could not find the .NET Framework 4 compiler on this PC.
  pause & exit /b 1
)

set "DEST=%LOCALAPPDATA%\Programs\Oatmeal Notes"
if not exist "%DEST%" mkdir "%DEST%"

taskkill /f /im "Oatmeal Notes.exe" >nul 2>&1

echo Building Oatmeal Notes...
"%CSC%" /nologo /target:winexe /optimize+ /out:"%DEST%\Oatmeal Notes.exe" /r:System.Windows.Forms.dll /r:System.Drawing.dll "%~dp0OatmealNotes.cs"
if errorlevel 1 (
  echo.
  echo Build failed. Please send the messages above to Claude.
  pause & exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Programs')+'\Oatmeal Notes.lnk'); $s.TargetPath=$env:DEST+'\Oatmeal Notes.exe'; $s.Save()"

echo.
echo Done! Oatmeal Notes is in your Start menu.
start "" "%DEST%\Oatmeal Notes.exe"
timeout /t 4 >nul
